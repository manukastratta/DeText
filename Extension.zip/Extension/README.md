# DeText
DeText browser extension, for automated content warnings. 
